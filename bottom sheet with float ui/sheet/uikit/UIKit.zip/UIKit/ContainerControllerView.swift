import SwiftUI
import Combine
import ObjectiveC
//
//// MARK: - Объект-хранилище для ContainerController
final class ContainerHolder: ObservableObject {
    @Published var container: ContainerController?
    @Published var containerPosition = ContainerPosition(top: 80, middle: nil, bottom: 80)
    
    func moveToTop(animation: Bool = true, velocity: CGFloat = 0.0, completion: (() -> Void)? = nil) {
        container?.move(type: .top, animation: animation, velocity: velocity, from: .custom, completion: completion)
    }
    func moveToBottom(animation: Bool = true, velocity: CGFloat = 0.0, completion: (() -> Void)? = nil) {
        container?.move(type: .bottom, animation: animation, velocity: velocity, from: .custom, completion: completion)
    }
    func moveTo(position: CGFloat, animation: Bool = true, velocity: CGFloat = 0.0, completion: (() -> Void)? = nil) {
        container?.move(position: position, animation: animation, type: .custom, velocity: velocity, from: .custom, completion: completion)
    }
}


class ContainerDemoViewController: UIViewController, ContainerControllerDelegate {
    var containerHolder = ContainerHolder()
    var animateAlongside: ((any UIViewControllerTransitionCoordinatorContext) -> Void)?

    var items: [String] = (1...5).map { "Элемент \($0)" }

    var container: ContainerController! {
        didSet {
            containerHolder.container = container
        }
    }
    
    let hostingFloat = floatViewController()
    
    private lazy var floatingButton: UIButton = {
        let button = UIButton()

        button.setImage(
            UIImage(systemName: "list.dash"), for: .normal
        )

        button.addTarget(
            self,
            action: #selector(move),
            for: .touchUpInside
        )

        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemBackground.withAlphaComponent(0.95)
        button.layer.cornerRadius = 20.0
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.5
        button.layer.shadowOffset = CGSize(width: 0, height: 2)
        button.layer.shadowRadius = 4.0
        button.layer.shouldRasterize = true
        button.layer.rasterizationScale = UIScreen.main.scale
        return button
    }()
    
    var backgroundHosting: UIViewController?
    var mainHosting: UIViewController?
    var sheetHosting: UIViewController?
    var floatHosting: UIViewController?

    var containerScrollView: UIScrollView?
    var containerFooterView: UIView?


    private var cancellables = Set<AnyCancellable>()
    
    private var buttonTopConstraint: NSLayoutConstraint?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        setupBackground()
        setupContainer()
        setupMainContent()
        setupFloatContent()
        observeContainerPosition()
        move()
        
    }
    
    private func configureView() {
        view.backgroundColor = .systemMint
        view.addSubview(floatingButton)

        // Create the initial bottom constraint relative to the container's position.
       
        buttonTopConstraint = floatingButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 552)
         
         NSLayoutConstraint.activate([
             buttonTopConstraint!,
             floatingButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
             floatingButton.heightAnchor.constraint(equalToConstant: 50),
             floatingButton.widthAnchor.constraint(equalToConstant: 50)
         ])
     }

    
    
    @objc
    func move(){
        containerHolder.containerPosition = ContainerPosition(top: 160, middle: nil, bottom: 160)
        containerHolder.moveToBottom()
    }
    
    
    
    private func setupBackground() {
        let hostingController = backgViewController()
        hostingController.view.translatesAutoresizingMaskIntoConstraints = false
        addChild(hostingController)
        view.insertSubview(hostingController.view, at: 0)
        NSLayoutConstraint.activate([
            hostingController.view.topAnchor.constraint(equalTo: view.topAnchor),
            hostingController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            hostingController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hostingController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        hostingController.didMove(toParent: self)
        backgroundHosting = hostingController
    }
    
    private func setupContainer() {
        let layout = ContainerLayout()
        layout.startPosition = .middle
        layout.positions = containerHolder.containerPosition
        container = ContainerController(addTo: self, layout: layout)
        container.delegate = self
        container.view.cornerRadius = 24
        container.view.addShadow()
        containerHolder.container = container
        
    }
    
    private func observeContainerPosition() {
        containerHolder.$containerPosition
            .sink { [weak self] newPositions in
                guard let self = self else { return }
                self.container.layout.positions = newPositions
                self.container.view.setNeedsLayout()
            }
            .store(in: &cancellables)
        
        
    }
    
    private func setupMainContent() {
        let hosting = mainViewController()
        let scroll = UIScrollView()
        hosting.view.translatesAutoresizingMaskIntoConstraints = false
        hosting.view.backgroundColor = .clear
        scroll.addSubview(hosting.view)
        NSLayoutConstraint.activate([
            hosting.view.topAnchor.constraint(equalTo: scroll.topAnchor),
            hosting.view.leadingAnchor.constraint(equalTo: scroll.leadingAnchor),
            hosting.view.trailingAnchor.constraint(equalTo: scroll.trailingAnchor),
            hosting.view.bottomAnchor.constraint(equalTo: scroll.bottomAnchor),
            hosting.view.widthAnchor.constraint(equalTo: scroll.widthAnchor)
        ])
        container.add(scrollView: scroll)
        addChild(hosting)
        hosting.didMove(toParent: self)
        mainHosting = hosting
        containerScrollView = scroll
        
    }
    
    private func setupFloatContent() {
        
        hostingFloat.view.translatesAutoresizingMaskIntoConstraints = false
        hostingFloat.view.layer.cornerRadius = 24
        
        guard let parentView = container?.view else { return }
        parentView.addSubview(hostingFloat.view)
        parentView.bringSubviewToFront(hostingFloat.view)
        
        NSLayoutConstraint.activate([
            hostingFloat.view.bottomAnchor.constraint(equalTo: container.view.bottomAnchor),
            hostingFloat.view.topAnchor.constraint(equalTo: container.view.topAnchor),
            hostingFloat.view.leftAnchor.constraint(equalTo: container.view.leftAnchor),
            hostingFloat.view.rightAnchor.constraint(equalTo: container.view.rightAnchor)
        ])
        
        addChild(hostingFloat)
        hostingFloat.didMove(toParent: self)
        floatHosting = hostingFloat
        
    }


    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        container.remove()
        container = nil
    }
    
    // MARK: - Методы делегата ContainerController
    func containerControllerShadowClick(_ containerController: ContainerController) {    }
    func containerControllerRotation(_ containerController: ContainerController) {}
    func containerControllerMove(_ containerController: ContainerController, position: CGFloat, type: ContainerMoveType, animation: Bool) {
         
        buttonTopConstraint?.constant = position - 100
              
              // Animate the constraint change if needed.
              if animation {
                  UIView.animate(withDuration: 0.3) {
                      self.view.layoutIfNeeded()
                  }
              } else {
                  view.layoutIfNeeded()
              }
              
              print("Container position: \(position)")
        
    }
}
