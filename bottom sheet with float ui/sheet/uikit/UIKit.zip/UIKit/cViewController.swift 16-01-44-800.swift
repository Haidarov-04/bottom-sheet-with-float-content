//
//  cViewController.swift
//  iosApp
//
//  Created by Haidarov N on 3/12/25.
//  Copyright © 2025 orgName. All rights reserved.
//

import UIKit

class backgViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .yellow

    }
    

}

class sheetViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue

    }
}

class floatViewController: UIViewController {
    
    var animateAlongside: ((any UIViewControllerTransitionCoordinatorContext) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        transitionCoordinator?.animate(alongsideTransition: { [self] context in
            animateAlongside?(context)
            animateAlongside = nil
        })
    }

}

class mainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red

    }
    

}

